from playGame import *

playGame()



